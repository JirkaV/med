VERSION = (0, 2, 0, 0, 'beta')
