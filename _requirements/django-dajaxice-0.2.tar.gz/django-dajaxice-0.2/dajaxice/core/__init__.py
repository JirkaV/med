from Dajaxice import Dajaxice
dajaxice_functions = Dajaxice()

from DajaxiceRequest import DajaxiceRequest
from Dajaxice import dajaxice_autodiscover
